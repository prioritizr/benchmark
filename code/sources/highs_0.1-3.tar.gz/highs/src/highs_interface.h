
#include <Rcpp.h>
#include <RcppCommon.h>
#include <Highs.h>
