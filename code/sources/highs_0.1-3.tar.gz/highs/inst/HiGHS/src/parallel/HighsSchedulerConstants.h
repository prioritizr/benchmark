/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                       */
/*    This file is part of the HiGHS linear optimization suite           */
/*                                                                       */
/*    Written and engineered 2008-2021 at the University of Edinburgh    */
/*                                                                       */
/*    Available as open-source under the MIT License                     */
/*                                                                       */
/*    Authors: Julian Hall, Ivet Galabova, Qi Huangfu, Leona Gottwald    */
/*    and Michael Feldmeier                                              */
/*                                                                       */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#ifndef HIGHS_SCHEDULER_CONSTANTS_H_
#define HIGHS_SCHEDULER_CONSTANTS_H_

struct HighsSchedulerConstants {
  enum Constants {
    kNumTryFac = 16,
    kMicroSecsBeforeSleep = 5000,
    kMicroSecsBeforeGlobalSync = 1000,
  };
};

#endif