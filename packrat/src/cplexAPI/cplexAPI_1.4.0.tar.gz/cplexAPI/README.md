cplexAPI
========

R Interface to C API of IBM ILOG CPLEX, depends on IBM ILOG CPLEX (>= 12.1)
