#' @include internal.R
NULL

#' @export
if (!methods::isClass("sf")) methods::setOldClass("sf")
NULL
